from pet import Pet

# Creating pet
my_pet = Pet("Max")
print(f"Creating pet: {my_pet.name} 🐶")

# Interacting with pet
my_pet.eat()
my_pet.play()
my_pet.sleep()

# Teaching tricks
my_pet.train("roll over")
my_pet.train("play dead")

# Showing tricks
my_pet.show_tricks()

# Status update
my_pet.get_status()
